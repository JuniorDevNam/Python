# Đảo ngược chuỗi

chuoi = str(input("Nhập chuỗi: "))
print(chuoi[::-1])
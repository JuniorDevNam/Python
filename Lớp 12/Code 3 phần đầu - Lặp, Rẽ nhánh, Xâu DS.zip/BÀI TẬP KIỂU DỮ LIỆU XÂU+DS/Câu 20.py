# Loại bỏ khoảng trắng đầu và cuối của một chuỗi.

chuoi = str(input("Nhập chuỗi: "))
print(chuoi.strip())
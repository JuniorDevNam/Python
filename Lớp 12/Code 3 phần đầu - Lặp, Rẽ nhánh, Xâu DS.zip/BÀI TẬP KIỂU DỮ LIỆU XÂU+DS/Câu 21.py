c = str(input("Nhập một chuỗi: "))
print("Chuỗi {} khi viết thường là: {}".format(c,c.lower()))
print("Chuỗi {} khi viết hoa là: {}".format(c,c.upper()))
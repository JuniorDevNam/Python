# Bài 1: Viết chương trình nhập vào ba số a, b, c, xuất ra màn hình số lớn nhất (max) của ba số đó.
a = int(input("Số a: "))
b = int(input("Số b: "))
c = int(input("Số c: "))
print("Số lớn nhất là: {}".format(max(a,b,c)))
# Bài 1: Viết chương trình nhập vào số nguyên n, xuất ra dãy số từ 1 đến n.
n = int(input("Nhập số nguyên n: "))
for x in range(1,n+1): print(x, end=" ")
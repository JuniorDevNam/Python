# Bài 9: Nhập vào số a và số nguyên dương n, tính a mũ n
a = int(input("Nhập một số a: "))
n = int(input("Nhập số nguyên dương n: "))
print(a**n)
n = int(input())
print("{}\n{}".format(len(str(n)),sum(int(x) for x in str(n))))
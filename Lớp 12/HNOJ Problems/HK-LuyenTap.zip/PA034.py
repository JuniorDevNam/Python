c = str(input())
if c.isalpha():
    print("YES")
else:
    print("NO")